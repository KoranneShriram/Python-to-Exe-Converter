import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import os


class ImageCompressorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Compressor")

        # Variables
        self.input_image_path = ""
        self.output_directory = ""
        self.target_size_kb = 0
        self.target_size_entry = tk.StringVar()

        # GUI Elements
        self.input_label = tk.Label(root, text="Select Image:")
        self.input_label.pack()

        self.select_button = tk.Button(root, text="Choose Image", command=self.select_image)
        self.select_button.pack()

        self.size_label = tk.Label(root, text="Target Size (KB):")
        self.size_label.pack()

        self.size_entry = tk.Entry(root, textvariable=self.target_size_entry)
        self.size_entry.pack()

        self.save_label = tk.Label(root, text="Save to Directory:")
        self.save_label.pack()

        self.save_button = tk.Button(root, text="Choose Directory", command=self.choose_save_directory)
        self.save_button.pack()

        self.compress_button = tk.Button(root, text="Compress Image", command=self.compress_image)
        self.compress_button.pack()

    def select_image(self):
        self.input_image_path = filedialog.askopenfilename(title="Select Image")
        if self.input_image_path:
            # Display selected image
            image = Image.open(self.input_image_path)
            image = image.resize((300, 300))  # Resize for display
            photo = ImageTk.PhotoImage(image)
            label = tk.Label(self.root, image=photo)
            label.image = photo
            label.pack()

    def choose_save_directory(self):
        self.output_directory = filedialog.askdirectory(title="Select Directory")

    def compress_image(self):
        try:
            if not self.input_image_path:
                messagebox.showerror("Error", "Please select an image to compress.")
                return

            if not self.output_directory:
                messagebox.showerror("Error", "Please select a directory to save the compressed image.")
                return

            try:
                self.target_size_kb = int(self.target_size_entry.get())
            except ValueError:
                messagebox.showerror("Error", "Please enter a valid integer for target size.")
                return

            if self.target_size_kb <= 0:
                messagebox.showerror("Error", "Target size must be greater than zero.")
                return

            # Calculate target size in bytes
            target_size_bytes = self.target_size_kb * 1024

            # Open the image
            img = Image.open(self.input_image_path)

            # Convert image to RGB mode if it has an alpha channel (RGBA)
            if img.mode == "RGBA":
                img = img.convert("RGB")

            # Initialize variables for iterative compression
            min_quality = 1
            max_quality = 100
            quality = max_quality

            # Binary search for the optimal quality level
            while min_quality <= max_quality:
                mid_quality = (min_quality + max_quality) // 2

                # Save image to a temporary file with the current quality level
                temp_file = "temp.jpg"
                img.save(temp_file, optimize=True, quality=mid_quality)

                # Check the size of the temporary file
                current_size = os.path.getsize(temp_file)
                os.remove(temp_file)

                # Adjust search range based on current size
                if current_size <= target_size_bytes:
                    quality = mid_quality
                    min_quality = mid_quality + 1
                else:
                    max_quality = mid_quality - 1

            # Save final compressed image
            file_path = os.path.join(self.output_directory, "compressed_image.jpg")
            img.save(file_path, optimize=True, quality=quality)
            messagebox.showinfo("Success", f"Image compressed and saved successfully.\nFinal quality level: {quality}")

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def get_image_file_size(self, file_path):
        # Helper function to get file size of the image
        return os.path.getsize(file_path)


if __name__ == "__main__":
    root = tk.Tk()
    app = ImageCompressorApp(root)
    root.mainloop()
